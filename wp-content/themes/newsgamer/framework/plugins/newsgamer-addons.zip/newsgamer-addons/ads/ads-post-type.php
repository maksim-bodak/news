<?php

function MipThemeFramework_Register_Adsystem_Post_Type(){
    register_post_type('mp_ads', array(
        'labels' => array(
            'name' => __('My Ads', 'Newsgamer' ),
            'singular_name' => __('Ad', 'Newsgamer' ),
            'add_new' => __('Add New', 'Newsgamer' ),
            'add_new_item' => __('Add New ad', 'Newsgamer' ),
            'edit_item' => __('Edit ad', 'Newsgamer' ),
            'new_item' => __('New ad', 'Newsgamer' ),
            'view_item' => __('View ad', 'Newsgamer' ),
            'search_items' => __('Search in ads', 'Newsgamer' ),
            'not_found' =>  __('No ads found', 'Newsgamer' ),
            'not_found_in_trash' => __('No ads found in Trash', 'Newsgamer' ),
            'parent_item_colon' => '',
            'menu_name' => __('Ads System', 'Newsgamer' ),
        ),
        'singular_label' => __('ads', 'Newsgamer' ),
        'public' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_admin_bar' => true,
        'menu_position' => 80,
        'capability_type' => 'post',
        'capabilities' => array(
            'publish_posts' => 'moderate_comments',
            'edit_posts' => 'moderate_comments',
            'edit_others_posts' => 'moderate_comments',
            'delete_posts' => 'moderate_comments',
            'delete_others_posts' => 'moderate_comments',
            'read_private_posts' => 'moderate_comments',
            'edit_post' => 'moderate_comments',
            'delete_post' => 'moderate_comments',
            'read_post' => 'moderate_comments',
        ),
        'hierarchical' => false,
        'supports' => array('title'),
        'has_archive' => false,
        'rewrite' => array( 'slug' => 'ad', 'with_front' => true, 'pages' => true, 'feeds'=>false ),
        'query_var' => false,
        'can_export' => true,
        'show_in_nav_menus' => true,
        'menu_icon' => 'dashicons-schedule'
    ));
}
