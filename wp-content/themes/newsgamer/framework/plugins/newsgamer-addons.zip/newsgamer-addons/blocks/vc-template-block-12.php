<?php
// don't load directly
if (!defined('ABSPATH')) die('-1');

if ( ! class_exists( 'MipThemeFramework_VCExtendAddonClass_Block12' ) ) {

    class MipThemeFramework_VCExtendAddonClass_Block12 {

        function __construct() {
            // We safely integrate with VC with this hook
            add_action( 'init', array( $this, 'integrateWithVC' ) );

            // Use this when creating a shortcode addon
            add_shortcode( 'gameland_block_12', array( $this, 'renderMyBlock12' ) );
        }

        public function integrateWithVC() {
            // Check if Visual Composer is installed
            if ( ! defined( 'WPB_VC_VERSION' ) ) {
                return;
            }

            /*
            Add your Visual Composer logic here.
            Lets call vc_map function to "register" our custom shortcode within Visual Composer interface.

            More info: http://kb.wpbakery.com/index.php?title=Vc_map
            */
            vc_map( array(
                "name" => __("Block Layout 12", 'vc_extend'),
                "base" => "gameland_block_12",
                "class" => "MipThemeFramework_block",

                "controls" => "full",
                "icon" => 'mp_icon', // or css class name which you can reffer in your css file later. Example: "vc_extend_my_class"
                "category" => __('Content', 'js_composer'),
                "params" => array(

                    array(
                        "param_name" => "mp_block_layout",
                        "type" => "dropdown",
                        //"group" => "General Settings",
                        "value" => array(
                            'Default Layout'  =>  'default',
                            'Flip Layout (switch left/right column)' =>  'flip',
                        ),
                        "heading" => __("Block Layout:", 'vc_extend'),
                        "description" => "Set how to display the layout",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "section_title",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '',
                        "holder" => "div",
                        "heading" => __("Block Title:", 'vc_extend'),
                        "description" => __("This is an optional field", 'vc_extend'),
                        "class" => ""
                    ),

                    array(
                        "param_name" => "section_link",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '',
                        "holder" => "div",
                        "heading" => __("Block Title Link:", 'vc_extend'),
                        "description" => __("This is an optional field", 'vc_extend'),
                        "class" => ""
                    ),

                    array(
                        "param_name" => "category_id",
                        "type" => "dropdown",
                        //"group" => "Left Column",
                        "value" => MipThemeFramework_Util::get_categoris_array(),
                        "heading" => __("Category filter:", 'vc_extend'),
                        "description" => "",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "category_multiple_id",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '',
                        "heading" => __("Multiple categories filter:", 'vc_extend'),
                        "description" => "(e.g.: 5,12,27); One or more category ids separated by commas",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "category_display",
                        "type" => "dropdown",
                        //"group" => "Left Column",
                        "value" => array(
                            'Root category (your input)'  =>  'root',
                            'Sub category' =>  'sub',
                            'No category' =>  'none'
                        ),
                        "heading" => __("Display categories as:", 'vc_extend'),
                        "description" => "",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "posttype_multiple_id",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '',
                        "heading" => __("Multiple post types filter:", 'vc_extend'),
                        "description" => "(e.g.: review, comics, show); One or more post types separated by commas",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_meta_display",
                        "type" => "dropdown",
                        //"group" => "Right Column",
                        "value" => array(
                            'Post Date'  =>  '1',
                            'Post Date + Post Author' =>  '2',
                            'Post Date + Post Comment Count' =>  '3',
                            'Post Date + Post Comment Count + Post Author' =>  '4',
                            'Post Date + Post Comment Count + Post Author + Post Views' =>  '5',
                            'Post Date + Post Comment Count + Post Views' =>  '6',
                            'Post Date + Post Views' =>  '7',
                            'Post Author' =>  '8',
                            'Post Comment Count' =>  '9',
                            'Post Comment Count + Post Author' =>  '10',
                            'Post Comment Count + Post Author + Post Views' =>  '11',
                            'Post Comment Count + Post Views' =>  '12',
                            'Post Views' =>  '13',
                            'No Post Meta' =>  '0',
                        ),
                        "heading" => __("Display Post Meta:", 'vc_extend'),
                        "description" => "",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_tag_slug",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '',
                        "heading" => __("Filter by tag slug:", 'vc_extend'),
                        "description" => "(e.g.: tag1, tag1, tag3); One or more tags separated by commas",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_sort",
                        "type" => "dropdown",
                        //"group" => "Left Column",
                        "value" => array(
                            'Latest' => 'date',
                            'Random posts' => 'rand',
                            'By name' => 'name',
                            'By Post Type' => 'type',
                            'Last Modified' => 'modified',
                            'Most Commented' => 'comment_count',
                            'Most Viewed' => 'mip_post_views_count',
                            'Most Most Viewed Last 24 Hours' => '_mip_post_views_count_24_hours_total',
                            'Most Most Viewed Last 7 Days' => '_mip_post_views_count_7_day_total'
                        ),
                        "heading" => __("Sort order:", 'vc_extend'),
                        "description" => "",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_limit",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '4',
                        "heading" => __("Posts per page:", 'vc_extend'),
                        "description" => "e.g.: 4; a integer number, used to display the number of posts per page",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_limit_images",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '1',
                        "heading" => __("Posts with image:", 'vc_extend'),
                        "description" => "e.g.: 1; a integer number, used to display the number of posts with images",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_text_chars_images",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '0',
                        "heading" => __("Limit Text Characters on articles with image", 'vc_extend'),
                        "description" => "(e.g.: 150); Keep blank or '0' for default limit",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_text_chars",
                        "type" => "textfield",
                        "group" => "Left Column",
                        "value" => '0',
                        "heading" => __("Limit Text Characters on text only articles", 'vc_extend'),
                        "description" => "(e.g.: 150); Keep blank or '0' for default limit",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_offset",
                        "type" => "textfield",
                        //"group" => "Left Column",
                        "value" => '0',
                        "heading" => __("Offset:", 'vc_extend'),
                        "description" => "e.g.: 3; a integer number of post to displace or pass over",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "post_paging",
                        "type" => "dropdown",
                        //"group" => "Left Column",
                        "value" => array(
                            'No paging' => 'none',
                            'Prev/next in block header' => 'header_paging',
                            'Prev/next in block footer' => 'footer_paging'
                        ),
                        "heading" => __("Allow paging:", 'vc_extend'),
                        "description" => "",
                        "holder" => "div",
                        "class" => ""
                    ),

                    array(
                        "param_name" => "block_css_class",
                        "type" => "textfield",
                        //"group" => "General Settings",
                        "value" => '',
                        "heading" => __("CSS Class", 'vc_extend'),
                        "holder" => "div",
                        "class" => ""
                    ),

                )
            ) );
        }

        /*
        Shortcode logic how it should be rendered
        */
        public function renderMyBlock12( $atts, $content = null ) {

            global $post, $mip_current_page, $miptheme;

            extract( shortcode_atts( array(
                'mp_block_layout' => 'default',
                'category_id' => '',
                'category_multiple_id' => '',
                'post_tag_slug' => '',
                'post_sort' => 'date',
                'post_limit' => '4',
                'post_limit_images' => '1',
                'post_offset' => '0',
                'section_title' => '',
                'section_link' => '',
                'category_display' => '',
                'post_paging' => '',
                'post_text_chars' => 0,
                'post_text_chars_images' => 0,
                'post_meta_display' => '',
                'block_css_class' => '',
                'posttype_multiple_id' => '',
            ), $atts ) );

            # CSS Classes
            $block_css_class        = ( $block_css_class != '' )    ? ' '. $block_css_class                 :   '';


            # Set Left Column
            $first_image_attr           = new MipThemeFramework_Image();
            $first_image                = $first_image_attr->get_image_attr_block12($mip_current_page->page_sidebar_template .'-1');

            $image_post_format_first    = $first_image[0];
            $image_post_format_second   = '';
            $image_post_first_width     = $first_image[1];
            $image_post_first_height    = $first_image[2];
            $image_post_second_width    = 0;
            $image_post_second_height   = 0;

            $shorten_text_chars         = ( $post_text_chars ) ? $post_text_chars : 0;
            $shorten_text_chars_images  = ( $post_text_chars_images) ? $post_text_chars_images : 0;

            if (!empty($category_id) and empty($category_multiple_id)) {
                $category_multiple_id = $category_id;
            }

            $category_display   = ( $category_display != '' )   ? $category_display : 'root';

            $args = array(
                        'cat'                   => $category_multiple_id,
                        'posts_per_page'        => $post_limit,
                        'offset'                => $post_offset,
                        'tag'                   => $post_tag_slug,
                        'post_status'           => 'publish',
                        'ignore_sticky_posts'   => true,
                        'orderby'               => ( (in_array($post_sort, array('mip_post_views_count', '_mip_post_views_count_7_day_total', '_mip_post_views_count_24_hours_total'))) ? 'meta_value_num' : $post_sort ),
                        'meta_key'              => ( (in_array($post_sort, array('mip_post_views_count', '_mip_post_views_count_7_day_total', '_mip_post_views_count_24_hours_total'))) ? $post_sort : '' ),
                        'post_type'             => $posttype_multiple_id
                    );

            // set unique posts if enabled
            if ( (bool)MipThemeFramework_UniquePosts::$unique_posts_enabled ) $args = array_merge($args, array('post__not_in' => MipThemeFramework_UniquePosts::$unique_posts_ids));

            $r = new WP_Query( apply_filters( 'block12_posts_args', $args ) );

            $output = '';

            if ($r->have_posts()) :
                $post_counter   = 1;

                $ajax_data      = 'data-block="block-01-left" data-cat="'. $category_multiple_id .'" data-count="'. $post_limit .'" data-count-img="'. $post_limit_images .'" data-max-pages="'. ($r->max_num_pages + 1) .'" data-offset="'. $post_offset .'" data-tag="'. $post_tag_slug .'" data-sort="'. $post_sort .'" data-display="'. $category_display .'" data-img-format-1="'. $image_post_format_first .'" data-img-format-2="'. $image_post_format_second .'" data-img-width-1="'. $image_post_first_width .'" data-img-width-2="'. $image_post_second_width .'" data-img-height-1="'. $image_post_first_height .'" data-img-height-2="'. $image_post_second_height .'" data-text="'. $shorten_text_chars .'" data-text-img="'. $shorten_text_chars_images .'" data-meta="'. $post_meta_display .'"';
                $ajax_block_id  = uniqid('mip-ajax-block-');

                $output .= '<aside id="'. $ajax_block_id .'" '. $ajax_data .'>'. ( ( ($section_title != '') || ( isset($post_paging) && ($post_paging == 'header_paging')  && ($r->max_num_pages > 1) ) ) ? '<header><h2>'. ( ( $section_link != '' ) ? '<a href="'. $section_link .'">'. $section_title .'</a>' : $section_title ) .'&nbsp;</h2><span class="borderline"></span>'. ( ( isset($post_paging) && ($post_paging == 'header_paging') && ($r->max_num_pages > 1) ) ? MipThemeFramework_Ajax::setAjaxNav( $ajax_block_id, 'ajax-nav-header' ) : '' ) .'</header>' : '' );
                $output .= '<div class="articles relative clearfix">';

                $post_ajax                              = new MipThemeFramework_Ajax();
                $post_ajax->ajax_query                  = $r;
                $post_ajax->post_id                     = $post->ID;
                $post_ajax->image_post_format_first     = $image_post_format_first;
                $post_ajax->image_post_format_second    = $image_post_format_second;
                $post_ajax->image_post_first_width      = $image_post_first_width;
                $post_ajax->image_post_first_height     = $image_post_first_height;
                $post_ajax->image_post_second_width     = $image_post_second_width;
                $post_ajax->image_post_second_height    = $image_post_second_height;
                $post_ajax->shorten_text_chars          = $shorten_text_chars;
                $post_ajax->shorten_text_chars_images   = $shorten_text_chars_images;
                $post_ajax->category_multiple_id        = $category_multiple_id;
                $post_ajax->category_display            = $category_display;
                $post_ajax->post_limit_images           = $post_limit_images;
                $post_ajax->post_meta                   = $post_meta_display;

                $output .= $post_ajax->formatBlock12();
                $output .= '</div>';

                if ( isset($post_paging) && ($post_paging == 'footer_paging') && ($r->max_num_pages > 1) ) {
                    $output_left .= MipThemeFramework_Ajax::setAjaxNav( $ajax_block_id );
                }

                $output .= '</aside>';
            endif;
            wp_reset_postdata();



            # Return output
            return '<section class="clearfix'.  $block_css_class .'">
                        '. $output .'
                    </section>';

        }

        /*
        Show notice if your plugin is activated but Visual Composer is not
        */
        public function showVcVersionNotice() {
            $plugin_data = get_plugin_data(__FILE__);
            echo '
            <div class="updated">
              <p>'.sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/vcomposer" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'vc_extend'), $plugin_data['Name']).'</p>
            </div>';
        }
    }
    // Finally initialize code
    new MipThemeFramework_VCExtendAddonClass_Block12();

}
