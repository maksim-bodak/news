<?php
/**
 * Newsgamer Custom Add-ons
 *
 * @link              http://themeforest.net/user/mip/portfolio
 * @since             1.0.0
 * @package           Newsgamer_addons
 *
 * @wordpress-plugin
 * Plugin Name:       Newsgamer Custom Add-ons
 * Plugin URI:        http://themeforest.net/user/mip/portfolio
 * Description:       Custom made Add-ons for Newsgamer Theme
 * Version:           1.8.5
 * Author:            MipThemes
 * Author URI: 	      http://themeforest.net/user/mip/portfolio
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

 // don't load directly
 if ( ! defined( 'ABSPATH' ) ) {
 	die( '-1' );
 }

 $theme = wp_get_theme(); // gets the current theme
 if ('NewsGamer' == $theme->name || 'NewsGamer' == $theme->parent_theme) {

     function MipThemeFramework_addons_activated() {
         return true;
     }

     // Add Custom VC Blocks
     require_once('blocks/vc-template-block-1.php');
     require_once('blocks/vc-template-block-2.php');
     require_once('blocks/vc-template-block-3.php');
     require_once('blocks/vc-template-block-4.php');
     require_once('blocks/vc-template-block-5.php');
     require_once('blocks/vc-template-block-6.php');
     require_once('blocks/vc-template-block-7.php');
     require_once('blocks/vc-template-block-8.php');
     require_once('blocks/vc-template-block-9.php');
     require_once('blocks/vc-template-block-10.php');
     require_once('blocks/vc-template-block-11.php');
     require_once('blocks/vc-template-block-12.php');
     require_once('blocks/vc-template-block-13.php');
     require_once('blocks/vc-template-block-14.php');
     require_once('blocks/vc-template-block-15.php');
     require_once('blocks/vc-template-block-ads-system.php');


     # Shortcode Classes
     require_once('shortcodes/class-shortcodes.php');
     add_shortcode('review', array( 'MipThemeFramework_Review', 'get_review' ));
     add_shortcode('miptheme_alert', array( 'MipThemeFramework_Alert', 'get_alert' ));
     add_shortcode('miptheme_dropcap', array( 'MipThemeFramework_Dropcap', 'get_dropcap' ));
     add_shortcode('miptheme_spacer', array( 'MipThemeFramework_Spacer', 'get_spacer' ));
     add_shortcode('miptheme_list', array( 'MipThemeFramework_List', 'get_list' ));
     add_shortcode('miptheme_listitem', array( 'MipThemeFramework_List', 'get_listitem' ));
     add_shortcode('miptheme_quote', array( 'MipThemeFramework_Quotes', 'get_quote' ));
     add_shortcode('miptheme_adssystem', array( 'MipThemeFramework_AdsSystem', 'get_ad' ));


     # Register Ads System Post class
     require_once('ads/ads-post-type.php');
     add_action('init','MipThemeFramework_Register_Adsystem_Post_Type');

     function MipThemeFramework_extensions_path() {
         return dirname(__FILE__) . '/extensions/';
     }

 }
