<?php

if ( ! class_exists( 'MipThemeFramework_Review' ) ) {

     class MipThemeFramework_Review {

         static function get_review( $atts ) {
             global $post;

             $mip_current_page              = mipthemeframework_get_mip_current_page();
             $review_post                   = MipThemeFramework_Util::miptheme_check_redux_post_meta(MIPTHEMEFRAMEWORK_THEMEREDUXNAME, $post->ID, '_mp_enable_review_post');

             if ( $review_post || ($review_post == 'enable') ) :
                 $review_post_style              = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_style');
                 $review_post_summary_type       = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_summary_type');
                 $review_post_summary_text       = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_summary_text');
                 $review_post_summary_text_good  = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_summary_text_good');
                 $review_post_summary_text_bad   = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_summary_text_bad');
                 $review_post_total_text         = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_total_text');
                 $review_post_criteria_count     = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_criteria_count');
                 $review_post_total_score        = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_total_score');

                 $review_post_user_total_score   = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, 'post_user_average');

                 $score         = round($review_post_total_score/10, 1);
                 $scoreClass    = round($review_post_total_score/10, 0);

                 $review_output  = '
                     <!-- start:review -->
                     <div class="review review-score-'. $scoreClass .'">
                         <div class="row bottom-margin">
                             <div class="col-lg-4 text-center">
                                 <div class="review-circle-wrapper">
                                     <div class="review-circle">
                                         <div class="meter-wrapper">
                                             <div class="meter-slice showfill">
                                                 <div class="meter" style="-webkit-transform:rotate('. (360 * ($score/10)) .'deg);-moz-transform:rotate('. (360 * ($score/10)) .'deg);-o-transform:rotate('. (360 * ($score/10)) .'deg);-ms-transform:rotate('. (360 * ($score/10)) .'deg);transform:rotate('. (360 * ($score/10)) .'deg);"></div>
                                                 <div class="meter fill"></div>
                                             </div>
                                         </div>
                                         <div class="rating">
                                             <div class="score-number">'. ( ( $review_post_style == 'percentage' ) ? round($review_post_total_score) .'<small>%</small>' : round($review_post_total_score/10, 1) ) .'</div>
                                         </div>
                                     </div>
                                 </div>
                                 <span class="score-desc">'. $review_post_total_text .'</span>
                             </div>
                             <div class="col-lg-8">';

                 if ( $review_post_summary_type == 'summ' ) :

                     $review_output  .= '
                                 <h4>'. __('Summary', 'Newsgamer') .'</h4>
                                 <p>'. do_shortcode($review_post_summary_text) .'</p>';

                 elseif ( $review_post_summary_type == 'good-bad' ) :

                     $review_output  .= '
                                 <div class="row">
                                     <div class="col-sm-6">
                                         <h4>'. __('The Good', 'Newsgamer') .'</h4>
                                         <ul class="good"><li><i class="fa fa-plus-circle"></i>'. str_replace(array("\r\n", "\r", "\n"), '</li><li><i class="fa fa-plus-circle"></i>', $review_post_summary_text_good) .'</li></ul>
                                     </div>
                                     <div class="col-sm-6">
                                         <h4>'. __('The Bad', 'Newsgamer') .'</h4>
                                         <ul class="bad"><li><i class="fa fa-minus-circle"></i>'. str_replace(array("\r\n", "\r", "\n"), '</li><li><i class="fa fa-minus-circle"></i>', $review_post_summary_text_bad) .'</li></ul>
                                     </div>
                                 </div>';

                 endif;

                 $review_output  .= '
                             </div>
                         </div>';



                 $author_review_output = '';
                 for ( $i = 1; $i <= $review_post_criteria_count; $i++ ) {
                     $crit_name      = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_criteria_'. $i .'');
                     $crit_value      = MipThemeFramework_Util::miptheme_diff_global_redux_post_meta($post->ID, '_mp_review_post_criteria_value_'. $i .'');
                     $author_review_output  .= '
                         <div class="progress">
                             <div class="progress-bar" role="progressbar" style="width: '. esc_attr($crit_value) .'%;">
                                 <span class="skill-number pull-left">'. ( ( $review_post_style == 'percentage' ) ? $crit_value .' %' : round($crit_value/10, 1) ) .'</span>
                                 <span class="skill-text pull-left">'. $crit_name .'</span>
                             </div>
                         </div>';
                 }

                 $user_review_output = '';
                 $postAverage        = get_post_meta($post->ID, 'post_user_average', true);
                 $user_rates         = get_post_meta($post->ID, 'post_user_raitings', true);
                 if (!empty ($user_rates)) {$usercriterias = $user_rates['criteria'];}
                 if ($postAverage !='0' && $postAverage !='') :
                     foreach ($usercriterias as $usercriteria) {
         				$perc_criteria = $usercriteria['average']*10;
                         $user_review_output  .= '
                             <div class="progress">
                                 <div class="progress-bar" role="progressbar" style="width: '. esc_attr($perc_criteria) .'%;">
                                     <span class="skill-number pull-left">'. ( ( $review_post_style == 'percentage' ) ? $perc_criteria .' %' : round($usercriteria['average'], 1) ) .'</span>
                                     <span class="skill-text pull-left">'. $usercriteria['name'] .'</span>
                                 </div>
                             </div>';
         			}
                 endif;

                 if ( $mip_current_page->review_post && $mip_current_page->review_post_users_enable && $review_post_user_total_score) {
                     $review_output .=
                         '<div class="row column-scores">
                             <div class="col-sm-6">
                                 <h4>'. esc_html__("Editor's score", "Newsgamer") .'<span>'. round($review_post_total_score/10, 1) .'</span></h4>
                                 '. $author_review_output .'
                             </div>
                             <div class="col-sm-6">
                                 <h4>'. esc_html__("User's score", "Newsgamer") .'<span>'. round($review_post_user_total_score, 1) .'</span></h4>
                                 '. $user_review_output .'
                             </div>
                         </div>';
                 } else {
                     $review_output .= $author_review_output;
                 }



                 $review_output  .= '</div><!-- end:review -->';

                 return $review_output;
             endif;
         }

     }

 }


 if ( ! class_exists( 'MipThemeFramework_Quotes' ) ) {

     class MipThemeFramework_Quotes {

         static function get_quote( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '',
                         'style' => '',
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="'. $style .'"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function quote_center( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="text-center"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function quote_left( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="text-left"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function quote_right( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="text-right"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function quote_box_center( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="boxquote text-center"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function quote_box_left( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="boxquote text-left"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function quote_box_right( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="boxquote text-right"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function pull_quote_left( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="pull-left"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

         static function pull_quote_right( $atts, $content = null ) {
             extract(shortcode_atts(
                     array(
                         'author' => '', /* empty for default color OR color profile OR custom #color */
                     ),
                     $atts
                 )
             );

             $footer = '';
             if ($author != '') {
                 $footer .= '<footer>'. $author .'</footer>';
             }
             return '<blockquote class="pull-right"><p>'. $content .'</p>'. $footer .'</blockquote>';
         }

     }

 }


 if ( ! class_exists( 'MipThemeFramework_Alert' ) ) {
     class MipThemeFramework_Alert {

         static function get_alert( $atts, $content = null) {
     		extract( shortcode_atts( array(
     			'type'  => 'warning',
     			'close' => 'true'
     		), $atts ) );

     		if($close == 'false') {
     			$btn    = '';
                 $class  = '';
     		} else{
     			$btn = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
                 $class  = ' alert-dismissible';
     		}

     		return '<div class="alert alert-' . esc_attr($type) . esc_attr($class) . '" role="alert">' . $btn . do_shortcode($content) . '</div>';
         }

     }
 }


 if ( ! class_exists( 'MipThemeFramework_Dropcap' ) ) {
     class MipThemeFramework_Dropcap {

         static function get_dropcap( $atts, $content = null) {
             extract(shortcode_atts(array(
     			'style'         => '',
                 'color'         => '',
                 'background'    => ''
     		), $atts));

     		if($style == '') {
     			$return = '';
     		} else{
     			$return = 'dropcap-'. $style;
     		}

             if($color == '') {
     			$class1 = '';
     		} else{
     			$class1 = 'color:'. $color .';';
     		}

             if($background == '') {
     			$class2 = '';
     		} else{
     			$class2 = 'background:'. $background .';';
     		}

             $class = ( ($class1 != '')||($class2 != '') ) ? ' style="'. $class1 . $class2 .'"' : '';

     		return '<span class="dropcap '. esc_attr($return) .'"'. $class .'>' .esc_html($content). '</span>';
         }

     }
 }


 if ( ! class_exists( 'MipThemeFramework_Spacer' ) ) {
     class MipThemeFramework_Spacer {

         static function get_spacer( $atts ) {
             extract( shortcode_atts( array(
     			'height'  => '50'
     		), $atts ) );

     		if($height == '') {
     			$return = '';
     		} else{
     			$return = 'style="height: '.esc_attr($height).'px;"';
     		}

     		return '<div class="spacer" ' . $return . '></div>';
         }

     }
 }


 if ( ! class_exists( 'MipThemeFramework_List' ) ) {
     class MipThemeFramework_List {

         static function get_list( $atts, $content = null ) {
             extract(shortcode_atts(array(), $atts));

 		    return '<ul class="shortcode-list">'. do_shortcode($content) . '</ul>';
         }

         static function get_listitem( $atts, $content = null ) {
             extract(shortcode_atts(array(
     			'icon'      => 'fa-check'
     		), $atts));

     		return '<li><i class="fa '.esc_attr($icon).'"></i> '. do_shortcode($content) . '</li>';
         }

     }
 }

 if ( ! class_exists( 'MipThemeFramework_AdsSystem' ) ) {
     class MipThemeFramework_AdsSystem {

         static function get_ad( $atts ) {
             extract( shortcode_atts( array(
     			'ad'  => '',
                'align'  => 'none',
                'hide_on_mobile'  => '0'
     		), $atts ) );

            $banner_id      = $ad;

            $ad_unit        = new MipThemeFramework_Ad();
            $ad_unit->id    = (int)$banner_id;
            // display ad unit
            return $ad_unit->formatContentAd( $align, $hide_on_mobile );

         }

     }
 }
