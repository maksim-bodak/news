<?php
/**
 * Copyright (c) 2015, Aleksey Korzun <aleksey@webfoundation.net>
 * All rights reserved.
 */

class PAFL_Exception extends Exception
{
}

